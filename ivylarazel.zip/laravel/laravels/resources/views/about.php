<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		body{
	
	background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(images/bg.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
	background-attachment: fixed;
}
			ul{
	list-style: none;
	text-decoration: none; 
	margin: 0px;
	background-color: #A7D3B5;
} 
ul li {
	display: inline-block;
	padding: 0px;
	margin-bottom: 20px;


}
ul li a{
 	text-decoration: none;
 	color: #fff;
 	padding:  10px 30px;
 	border: 1px solid #fff; 
 	transition: 0.20s ease;
}
ul li a:hover{
	color: #27B8B8;
	}
.gallery{
	width: 100px;
	height: 100px;
	margin-top: 20px;
	margin-bottom: 0px;
	margin-right: 700px;
}
footer{
	background-image: url(images/footer.png);
	font-size: 40px;
	color: #fff ;
	}
	h1{
		text-align: center;
	}
	.gallery1{
		display: inline-block;
		width: 350px;
		height: 400px;
		margin-left: 70px;
		}
		.gallery1 img{
	width: 230px;
	padding: 5px;
	filter: grayscale(100%);
	transition: 1s;
	border-radius: 20px;
}
.gallery1 img:hover{
filter: grayscale(0);
transform: scale(1.1);
}
form{
	text-align: left;
	color: white;
	margin-left: 70px;
}
.info{
	font-size: 25px;
	margin-left: 20px;
	color: white;
	background: none;
}


	</style>
</head>
<body>
	<div>
		<ul>
			<li><a href="home">HOME</a></li>
			<li><a href="about">ABOUT</a></li>
			<li><a href="contact">CONTACT</a></li>

		</ul>
	</div>
	<div>
		 <h1>My Portfolio</h1>
	</div>
	<table>
		<tr>
		<th></th>
		<th>
			
			
		</th>
	</tr>

	<tr>
		<td><img src="images/me.jpg"  class="gallery1"></td>
		<td class="info">
			<label class="info">Name:</label> Ivy Mae Espelita<br>
			<label class="info">Age:</label>21 yrs/old<br>
			<label class="info">Year&Course:</label>BS-IT 3 Block 3<br>
			<label class="info">Address:</label>Camanang Ruiverside Urdaneta City<br>
			<label class="info">Motto: </label>ime is gold 
		</td>
	</tr>
	</table>
		
	<center>
	<div>
		<footer>(¯`·.¸¸.-> °º   🎀  𝐼𝓋𝓎 𝑀𝒶𝑒 𝐸𝓈𝓅𝑒𝓁𝒾𝓉𝒶  🎀   º° >-.¸¸.·`¯(</footer>
	</div>
	</center>

</body>
</html>
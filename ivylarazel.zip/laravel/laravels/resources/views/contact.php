<!DOCTYPE html>
<html>
<head>
	<title> </title>
	<style type="text/css">
		*{
		background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(images/bg.jpg);
		background-repeat: no-repeat;
		background-size: cover;
		background-position: center;
	background-attachment: fixed;
}
			ul{ 

	list-style: none;
	text-decoration: none; 
	margin: 0px;
	background-color: #A7D3B5;
} 
ul li {
	display: inline-block;
	padding: 0px;
	margin-bottom: 20px;


}
ul li a{
 	text-decoration: none;
 	color: #fff;
 	padding:  10px 30px;
 	border: 1px solid #fff; 
 	transition: 0.20s ease;
}
ul li a:hover{
	color: #27B8B8;
	}

footer{
	font-size: 40px;
	color: #fff ;
	}
	h1{
		text-align: center;
		font-size: 70px;
		font-weight: bolder;
	}
	h2{
		text-align: center;
	}
p{
	text-align: center;
	font-weight: bold;
}
.Messege{
	height: 70px;

}
input{
	text-align: left;
	width: 300px;
	background-color: white;
}
label{
	text-align: left;

}
textarea {
	width: 300px;
	height: 100px;
}
.gallery{
	width: 100px;
	height: 100px;
	margin-top: 20px;
	margin-bottom: 0px;
	margin-right: 700px;
}
.send{
	width: 100px;
	height: 50px;
	margin-right: 85px;
	margin-bottom: 30px;
	background: white;
}
form{
	text-align: right;
	margin-right: 70%;
	font-weight: bold;


}
label{
	margin-right: 20px;
}


.contact{
	background: white;
}
footer{
	background-image: url(images/footer.png);
	font-size: 40px;
	color: #fff ;
	}

	</style>
</head>
<body>
	<div>
		<ul>
			<li><a href="home">HOME</a></li>
			<li><a href="about">ABOUT</a></li>
			<li><a href="contact">CONTACT</a></li>

		</ul>
	</div>
	<div>
		 <h1>My Portfolio</h1>
	</div>
	<div>
		 <h2>Contact   US </h2>	
		 <form>
	 <label>Name:</label><input type="text" name="Name" placeholder="Name" class="contact"><br>
		  <label>Email:</label><input type="text" name="Email" placeholder="Email" required="enter your Email" / class="contact"><br>
		   <label>Subject:</label><input type="text" name="Subject" placeholder="Subject" required="whats  your  purpose" class="contact"><br>
		    <label>Messege:</label><textarea placeholder="Messege" class="contact" name="Messege" required="write  a Messege"></textarea><br>

		   <input type="submit" name="btn-send" placeholder="send" class="send">
		   </form>
	<center>
	<div>
		<footer>(¯`·.¸¸.-> °º   🎀  𝐼𝓋𝓎 𝑀𝒶𝑒 𝐸𝓈𝓅𝑒𝓁𝒾𝓉𝒶  🎀   º° >-.¸¸.·`¯(</footer>
	</div>
	</center>
	

</body>
</html>
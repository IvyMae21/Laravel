<!DOCTYPE html>
<html>
<head>
	<title></title>

	<style type="text/css">

body{
	
	background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(images/bg.jpeg);
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
	background-attachment: fixed;
}

ul{
	list-style: none;
	font-weight: bold;
}

ul li{
	margin-left: 23px;
	display: inline-block; 
	font-family: Century Gothic;
}
ul li a{
	text-decoration: none;
	color: #fff;
	padding: 8px 30px;
	border: 1px solid #fff;


}
.title{
	font-family: Century Gothic;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%,-50%);

}
.title h1{
	color: #fff;
	font-size: 70px;
}
.button{
	font-family: Century Gothic;
	position: absolute;
	top: 60%;
	left: 50%;
	transform: translate(-50%,-50%);
}
.btn{
	border: 1px solid #fff;
	padding: 10px 30px;
	color: #fff;
	text-decoration: none;

}
footer{
	text-align: center;
	font-weight: bold;
	margin-top: 43%;
	background-color: #5B827C;
	font-family: Century Gothic;
	padding: 10px;
}
h1{
	margin-bottom:  10px;
	font-weight: bold;
	font-size: 50px;
	color: white;
}
</style>
</head>
<body>
	<center>
	<ul>
		<li><a href="home">HOME</a></li>
			<li><a href="about">ABOUT</a></li>
			<li><a href="contact">CONTACT</a></li>
	</ul>
<div class="title">
	<h1></h1>
</div>

<div class="button">
	<h1> IVY ESPELITA</h1>
	<a href="#" class="btn">WATCH VIDEO</a>
	<a href="#" class="btn">LEARN MORE</a>

</div>
</center>


<footer>(¯`·.¸¸.-> °º   🎀  𝐼𝓋𝓎 𝑀𝒶𝑒 𝐸𝓈𝓅𝑒𝓁𝒾𝓉𝒶  🎀   º° >-.¸¸.·`¯(</footer>

</body>
</html>